//
// Created by zyd on 23-3-29.
//

#ifndef UNIVERSADRIVER_ADC_H
#define UNIVERSADRIVER_ADC_H

#include "stm32f10x.h"

void adc_config();
unsigned char adc_get(unsigned short *adcVal);

#endif //UNIVERSADRIVER_ADC_H
