//
// Created by m on 2023/3/14.
//
#include <stdio.h>
#include "bsp_uart1.h"
#include "stm32f10x.h"
#include "pwm.h"
#include "adc.h"

enum {pwm_ch = 4};

#define def_adc_lsb (3.3 / 4095)
#define def_adc_to_uv(val) ((unsigned long )(def_adc_lsb * val * 1000000))

void delay(unsigned long ms){
    unsigned long i, k;
    for(i = 0; i < ms; ++i){
        for(k = 0; k < 60000; ++k);
    }
}

int main(){
    unsigned short adcVal = 0;

    bsp_uart1_init();
    pwm_config(10000);
    adc_config();

    pwm_out(pwm_ch, 20);

    for(;;){
        if(adc_get(&adcVal) == 1){
            printf("adc val : %d uV\n", def_adc_to_uv(adcVal));
        }
        delay(10000);
    }
}

int _write(int fd, char *ptr, int len) {
    int i = 0;    unsigned char *p = (unsigned char*)ptr;

    for(i = 0; i < len; ++i){
        bsp_uart1_writeByte(*p++);
    }

    return len;
}