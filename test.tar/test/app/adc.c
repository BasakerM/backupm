//
// Created by zyd on 23-3-29.
//

#include "adc.h"

void adc_config(){
    GPIO_InitTypeDef GPIO_InitStructure;
    ADC_InitTypeDef ADC_InitStuctrue;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE); // 使能AHB预分频器到端口A的开关
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE); // 使能AHB预分频器到外设ADC1的开关
    RCC_ADCCLKConfig(RCC_PCLK2_Div8); // 时钟分频72M/8=9M 最大时钟不超过14M
    ADC_DeInit(ADC1); // ADC复位
    ADC_DMACmd(ADC1, DISABLE); // 禁止DMA

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0; // 定义PA0，PA1脚为AD输入
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN; // IO口为模拟输入模式
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure); // 按以上参数设置A口 A0/A1

    ADC_InitStuctrue.ADC_Mode = ADC_Mode_Independent; // ADC 独立工作模式
    ADC_InitStuctrue.ADC_ScanConvMode = DISABLE; // 是否扫描_单通道
    ADC_InitStuctrue.ADC_ContinuousConvMode = DISABLE; // 是否连续_单次
    ADC_InitStuctrue.ADC_ExternalTrigConv=ADC_ExternalTrigConv_None; // 不用外部触发，软件触发转换
    ADC_InitStuctrue.ADC_DataAlign=ADC_DataAlign_Right; // 数据右对齐
    ADC_InitStuctrue.ADC_NbrOfChannel = 1; // 结构体_ADC-通道个数_单通道
    ADC_Init(ADC1,&ADC_InitStuctrue); // 按以上参数设置ADC1

    ADC_RegularChannelConfig(ADC1, ADC_Channel_0, 1, ADC_SampleTime_239Cycles5);
    //配置内容和ADC外设的具体对接函数 (ADC端口1 ,ADC通道0 ,转换序号-第1个转换 ,转换的周期)
    ADC_Cmd(ADC1,ENABLE); // 使能ADC1
    ADC_ResetCalibration(ADC1); // ADC寄存器复位校准函数
    while(ADC_GetResetCalibrationStatus(ADC1)); // 等待上一步完成
    ADC_StartCalibration(ADC1); // 开始指定ADC的校准状态
    while(ADC_GetCalibrationStatus(ADC1)); // 等待上一步完成
}

static unsigned char _adc_get_fsm = 0;
unsigned char adc_get(unsigned short *adcVal){
    switch (_adc_get_fsm) {
        case 0: // 触发
            ADC_SoftwareStartConvCmd(ADC1, ENABLE);
            ++_adc_get_fsm;
            break;
        case 1: // 等待转换完成
            if(ADC_GetFlagStatus(ADC1,ADC_FLAG_EOC) != RESET){
                *adcVal = ADC_GetConversionValue(ADC1);
                _adc_get_fsm = 0;
                return 1;
            }
            break;
    }
    return 0;
}