//
// Created by zyd on 23-3-27.
//

#include "pwm.h"

#define _def_pwm_system_core_clk 72000000
#define _def_pwm_use_tim TIM2
#define _def_pwm_channel_max 4

void pwm_config(unsigned long freq_hz){
    GPIO_InitTypeDef GPIO_InitStructure;
    TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
    TIM_OCInitTypeDef TIM_OCInitStructure;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);
    GPIO_PinRemapConfig(GPIO_PartialRemap2_TIM2, ENABLE); // 部分映射, CH1,2,3,4 对应PA0,PA1,PB10,PB11
    GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable, ENABLE); // 禁用JTAG

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10 | GPIO_Pin_11; // CH3,4
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);

    TIM_TimeBaseStructure.TIM_Period = 100 - 1;//自动重装值
    TIM_TimeBaseStructure.TIM_Prescaler = _def_pwm_system_core_clk / 100 / freq_hz - 1; //时钟预分频数
    TIM_TimeBaseStructure.TIM_ClockDivision = 0; // 时钟分频系数
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;//TIM向上计数模式
    TIM_TimeBaseInit(_def_pwm_use_tim, &TIM_TimeBaseStructure); //初始化TIM2

    TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1; // PWM模式1
    TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable; // 输出使能
    TIM_OCInitStructure.TIM_Pulse = 0;
    TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
    TIM_OC3Init(_def_pwm_use_tim, &TIM_OCInitStructure); // 初始化CH3
    TIM_OC4Init(_def_pwm_use_tim, &TIM_OCInitStructure); // 初始化CH4

    TIM_OC3PreloadConfig(_def_pwm_use_tim, TIM_OCPreload_Enable); // 使能预装载器
    TIM_OC4PreloadConfig(_def_pwm_use_tim, TIM_OCPreload_Enable); // 使能预装载器
    TIM_ARRPreloadConfig(_def_pwm_use_tim, ENABLE); //使能重装寄存器

    TIM_Cmd(_def_pwm_use_tim, ENABLE);//使能定时器TIM2
}

#define _def_TIM_SetCompare_index_max _def_pwm_channel_max
typedef void (*TIM_SetCompare_t)(TIM_TypeDef*, uint16_t);
TIM_SetCompare_t TIM_SetCompare[_def_TIM_SetCompare_index_max + 1] = {
        0, 0, 0, TIM_SetCompare3, TIM_SetCompare4
};

void pwm_out(unsigned char channel, unsigned char pct){
    TIM_SetCompare[(channel > _def_TIM_SetCompare_index_max)? (_def_TIM_SetCompare_index_max): (channel)]
    (_def_pwm_use_tim, (pct > 100)? (100):(pct));
}
