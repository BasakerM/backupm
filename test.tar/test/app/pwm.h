//
// Created by zyd on 23-3-27.
//

#ifndef UNIVERSADRIVER_PWM_H
#define UNIVERSADRIVER_PWM_H

#include "stm32f10x.h"

void pwm_config(unsigned long freq_hz);
void pwm_out(unsigned char channel, unsigned char pct);

#endif //UNIVERSADRIVER_PWM_H
