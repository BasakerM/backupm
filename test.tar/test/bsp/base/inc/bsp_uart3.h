#ifndef _bsp_uart3_h
#define _bsp_uart3_h

#include "stm32f10x.h"

/* uart3 接收中断 */
#define bsp_uart3_isr USART3_IRQHandler

/*
    说明 :
        初始化uart3
    参数 :
        void
    返回 :
        void
*/
void bsp_uart3_init(void);

/*
    说明 :
        往uart3写一个字节的数据
    参数 :
        unsigned char ch : 数据
    返回 :
        void
*/
static inline void bsp_uart3_writeByte(unsigned char ch)
{
    while((USART3->SR & USART_FLAG_TXE) == (uint16_t)RESET);
    USART3->DR = ((uint16_t)ch & (uint16_t)0x01FF);
}

/*
    说明 :
        从uart3读一个字节的数据,只能在 bsp_bsp_uart3_isr() 中调用
    参数 :
        void
    返回 :
        unsigned char ch : 数据
*/
static inline unsigned char bsp_uart3_readByte(void)
{
    return (unsigned char)(USART3->DR & (uint16_t)0x01FF);
}

#endif
