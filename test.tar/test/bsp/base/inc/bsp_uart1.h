#ifndef _bsp_uart1_h
#define _bsp_uart1_h

#include "stm32f10x.h"

/* uart1 接收中断 */
#define bsp_uart1_isr USART1_IRQHandler

/*
    说明 :
        初始化uart1
    参数 :
        void
    返回 :
        void
*/
void bsp_uart1_init(void);

/*
    说明 :
        往uart1写一个字节的数据
    参数 :
        unsigned char ch : 数据
    返回 :
        void
*/
static inline void bsp_uart1_writeByte(unsigned char ch)
{
    while((USART1->SR & USART_FLAG_TXE) == (uint16_t)RESET);
    USART1->DR = ((uint16_t)ch & (uint16_t)0x01FF);
}

/*
    说明 :
        从uart1读一个字节的数据,只能在 bsp_bsp_uart1_isr() 中调用
    参数 :
        void
    返回 :
        unsigned char ch : 数据
*/
static inline unsigned char bsp_uart1_readByte(void)
{
    return (unsigned char)(USART1->DR & (uint16_t)0x01FF);
}

#endif
