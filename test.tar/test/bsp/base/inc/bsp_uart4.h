#ifndef _bsp_uart4_h
#define _bsp_uart4_h

#include "stm32f10x.h"

/* uart4 接收中断 */
#define bsp_uart4_isr UART4_IRQHandler

/*
    说明 :
        初始化uart4
    参数 :
        void
    返回 :
        void
*/
void bsp_uart4_init(void);

/*
    说明 :
        往uart4写一个字节的数据
    参数 :
        unsigned char ch : 数据
    返回 :
        void
*/
static inline void bsp_uart4_writeByte(unsigned char ch)
{
    while((UART4->SR & USART_FLAG_TXE) == (uint16_t)RESET);
    UART4->DR = ((uint16_t)ch & (uint16_t)0x01FF);
}

/*
    说明 :
        从uart4读一个字节的数据,只能在 bsp_bsp_uart4_isr() 中调用
    参数 :
        void
    返回 :
        unsigned char ch : 数据
*/
static inline unsigned char bsp_uart4_readByte(void)
{
    return (unsigned char)(UART4->DR & (uint16_t)0x01FF);
}

#endif
