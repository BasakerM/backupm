#ifndef _bsp_spi3_h
#define _bsp_spi3_h

#include "stm32f10x.h"

/*
    说明：
        初始化为主机
    参数：
        void
    返回：
        void
*/
void bsp_spi2_initMaster(void);

/*
    说明：
        初始化为从机
    参数：
        unsigned char (*call)(unsigned char)：
            说明：
                接收中断回调
            参数：
                unsigned char：发送中断时，传入接收到的字节
            返回：
                处理完回调后返回一个要发送的字节
    返回：
        void
*/
void bsp_spi3_initSlave( unsigned char (*call)(unsigned char) );

/*
    说明：
        先写后读，仅主机模式下有效
    参数：
        unsigned char：写的数据
    返回：
        unsigned char
*/
static inline unsigned char bsp_spi2_writeRead(unsigned char dat)
{
	unsigned char ch = 0;
	
	// GPIO_ResetBits(GPIOA, GPIO_Pin_15);
	while(SPI_I2S_GetFlagStatus(SPI2, SPI_I2S_FLAG_TXE) == RESET) {}
	SPI_I2S_SendData(SPI2, dat);
	while(SPI_I2S_GetFlagStatus(SPI2, SPI_I2S_FLAG_RXNE) == RESET) {}
	ch = SPI_I2S_ReceiveData(SPI2);
	// GPIO_SetBits(GPIOA, GPIO_Pin_15);
	
	return ch;
}

#endif
