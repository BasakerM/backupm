#ifndef _bsp_uart2_h
#define _bsp_uart2_h

#include "stm32f10x.h"

/* uart2 接收中断 */
#define bsp_uart2_isr USART2_IRQHandler

/*
    说明 :
        初始化uart2
    参数 :
        void
    返回 :
        void
*/
void bsp_uart2_init(void);

/*
    说明 :
        往uart2写一个字节的数据
    参数 :
        unsigned char ch : 数据
    返回 :
        void
*/
static inline void bsp_uart2_writeByte(unsigned char ch)
{
    while((USART2->SR & USART_FLAG_TXE) == (uint16_t)RESET);
    USART2->DR = ((uint16_t)ch & (uint16_t)0x01FF);
}

/*
    说明 :
        从uart2读一个字节的数据,只能在 bsp_bsp_uart2_isr() 中调用
    参数 :
        void
    返回 :
        unsigned char ch : 数据
*/
static inline unsigned char bsp_uart2_readByte(void)
{
    return (unsigned char)(USART2->DR & (uint16_t)0x01FF);
}

#endif
